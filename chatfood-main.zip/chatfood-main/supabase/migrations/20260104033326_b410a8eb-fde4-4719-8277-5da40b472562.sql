INSERT INTO public.whatsapp_integrations (
  user_id,
  phone_number_id,
  waba_id,
  access_token,
  display_phone_number,
  status,
  registration_status
) VALUES (
  'd541fbb2-a594-4c37-bd66-f3e010eab914',
  '846406075230215',
  '1146958984222017',
  'EAALR39d9S10BPcPtT91D69hapBVZC9ZCxmTo4JJbPYIQiEUkvmmsTyAZATx7uEpHAQBth3IAQvgrZAgUti69DiBOPb6fmqCdoCWrYckQtDeFSHK55hkjXxhLqgdFlMzDqP8hysK9lFdZC0Uqu9xDpRQ9P9se3ShyS6ZAzEaz0Bnsd1hUmuuzHCxLgdUOxPmAZDZD',
  '+33652434528',
  'active',
  'registered'
);